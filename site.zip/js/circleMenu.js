const toggle = document.querySelector(".toggle");
const menu = document.querySelector(".menu");

toggle.onclick = ()=>{menu.classList.toggle("active")};